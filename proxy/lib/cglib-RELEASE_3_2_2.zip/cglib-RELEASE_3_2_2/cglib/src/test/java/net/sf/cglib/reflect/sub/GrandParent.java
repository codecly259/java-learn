package net.sf.cglib.reflect.sub;
abstract class GrandParent {
    public String getHerb() {
        return "dill";
    }
}
