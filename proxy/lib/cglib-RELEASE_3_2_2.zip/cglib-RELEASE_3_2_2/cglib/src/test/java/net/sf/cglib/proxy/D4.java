package net.sf.cglib.proxy;

class D4 implements DI1, DI3 {
    public String herby() {
        return "D4";
    }
    
    public String derby() {
        return "D4";
    }
    
    public String extra() {
        return "D4";
    }
}
